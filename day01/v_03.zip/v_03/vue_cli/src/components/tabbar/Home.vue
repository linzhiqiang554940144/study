<template>
  <div class="app-home">
     <!--第一个：顶部导航条 学子商城-->
     <mt-header fixed title="学子商城"></mt-header>
     <!--第二个：轮播图-->
     <mt-swipe :auto="2500">
        <mt-swipe-item>
            <img src="" />
        </mt-swipe-item>
     </mt-swipe>
     <!--第三个：九宫格-->
     <!--第四个：底部导航栏tabbar-->
  </div>  
</template>
<script>
 export default {
   data(){
     return {}
   }
 }  
</script>
<style>
</style>