<template>
  <div class="app-home">
     <!--第一个：顶部导航条 学子商城-->
     <mt-header fixed title="学子商城"></mt-header>
     <!--第二个：轮播图-->
     <mt-swipe :auto="2500">
        <mt-swipe-item v-for="item in list" :key="item.id">
            <img :src="item.img_url" />
        </mt-swipe-item>
     </mt-swipe>
     <!--第三个：九宫格-->
     
     <!--第四个：底部导航栏tabbar-->
  </div>  
</template>
<script>
 export default {
   data(){
     return {
       list:[
         {id:1,img_url:"http://127.0.0.1:3000/img/banner1.png"},
         {id:2,img_url:"http://127.0.0.1:3000/img/banner2.png"},
         {id:3,img_url:"http://127.0.0.1:3000/img/banner3.png"},                  
         ]
     }
   }
 }  
</script>
<style>
/*轮播图设置父元素高度*/
.app-home .mint-swipe{
  height:200px;
}
.app-home .mint-swipe img{
  width:100%;
}
</style>